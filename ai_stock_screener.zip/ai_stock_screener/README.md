# AI Momentum Stock Screener — starter app

A Streamlit stock screener with an explainable 0–100 momentum score. This is a rule-based AI-style ranking prototype, **not** a trained predictive AI model. It uses Yahoo Finance via `yfinance` for recent daily price/volume bars. It does not place trades.

## Run

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local URL shown in your terminal. Enter up to 60 comma-separated ticker symbols, choose price/RVOL/score filters, and press **Run screener**.

## Limitations

- Scans your supplied watchlist, not the entire U.S. stock market.
- Uses daily bars; relative volume is not time-of-day normalized.
- Data may be delayed, incomplete, or unavailable, particularly for thinly traded tickers.
- No news/earnings classifier, real-time data, VWAP, machine-learning model, alerts, or broker API.
- Stops, targets and share sizes are illustrative only; slippage/gaps can exceed calculated risk.
- Paper research only; no order placement.

## Next upgrade

Connect a licensed real-time market-data provider, add a market-wide symbol universe, calculate intraday time-adjusted RVOL and VWAP, add sourced news and earnings events, and validate rankings with out-of-sample backtests before relying on them.
